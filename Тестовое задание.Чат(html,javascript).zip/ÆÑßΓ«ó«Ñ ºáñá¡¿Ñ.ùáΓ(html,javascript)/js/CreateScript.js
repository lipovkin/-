var getFields = function () {

    //var allFields = document.getElementsByTagName("input");

    var fieldsObj = {};
    fieldsObj['name'] = document.getElementById('name').value;
    fieldsObj['email'] = document.getElementById('email').value;
    fieldsObj['pass'] = document.getElementById('pass').value;
    fieldsObj['phone'] = document.getElementById('tel').value;

    //alert(JSON.stringify(fieldsObj));

    localStorage.setItem("userData", JSON.stringify(fieldsObj));

};