var userData = JSON.parse(localStorage.getItem("userData"));
var outName = document.getElementsByClassName("accountWordNew");
outName[0].innerHTML = userData.name;

/*var divBox = document.createElement("div");
 divBox.className = "textBox";
 //divBox.innerHTML = document.getElementById("text");
 var test = document.getElementsByClassName("gradientBox")[0];
 test.appendChild(divBox);*/


var sendMessage = function () {
    var nowManySends = 0;
    nowManySends ++;

    if(nowManySends > 8){
        var clearTextBox =  document.getElementsByClassName('textBox');
        clearTextBox.parentNode.removeChild(clearTextBox);
    }


    var mText = document.getElementById("messageText").value;
    var divBox = document.createElement("div");
    divBox.className = "textBox";

    var para = document.createElement("p");
    para.setAttribute("style", "font-size: 150%; color: black;");
    para.innerHTML = mText;
    divBox.appendChild(para);

    var test = document.getElementsByClassName("gradientBox")[0];
    test.appendChild(divBox);

};

